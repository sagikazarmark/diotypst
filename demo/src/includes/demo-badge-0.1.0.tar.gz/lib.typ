// A tiny demo package embedded into the app binary as a verbatim archive.
#let badge(body, fill: rgb("eef2ff")) = box(
  inset: 6pt,
  radius: 4pt,
  fill: fill,
  body,
)
